import React, { Component } from "react";
import { TextInput, View, Text, Button, StyleSheet, AppRegistry} from "react-native";

export default class App extends React.Component {
  state = {
    miles: null,
    kilometers: null,
    miles1: null,
    kilometers1: null,
  };
  updateState = () =>
    this.setState({
      kilometers: (this.state.miles * 1.609344)
      //kilometers: (this.state.kilometers - 32) * 5 / 9
    });
  updateState1 = () =>
    this.setState({
      //miles: (this.state.miles * 9/5) + 32,
      miles1: (this.state.kilometers1 * .62137),
    });
  render() {
    const { miles, kilometers, miles1, kilometers1 } = this.state;

    return (
      <View style={{flex: 1, justifyContent: 'center',alignItems: 'center'}}>
                    
        {/* <h1> Temperature Converter</h1> */}

        <TextInput
          value={this.state.miles}
          onChangeText={(miles) => this.setState({ miles })}
          placeholder={"miles Here"}
        />
        <Text> {kilometers} </Text>

        <Button
          onPress={() => {
            this.updateState();
          }}
          title="Convert Miles to Kilometers"
          color = '#ff5c5c'
        />

        <Text>{"\n"}</Text>

        <TextInput
          value={this.state.kilometers1}
          onChangeText={(kilometers1) => this.setState({ kilometers1 })}
          placeholder={"kilometers Here"}
        />
        <Text> {miles1} </Text>

        <Button
          onPress={() => {
            this.updateState1();
          }}
          title="Convert Kilometers to miles"
          color="#841584"
        />
      </View>

      
    );
  }
}
